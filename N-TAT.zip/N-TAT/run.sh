#!/bin/bash

# Activate virtual environment if any (optional)
# source venv/bin/activate

# Navigate to GUI folder
cd gui

# Run main dashboard
python3 dashboard.py

