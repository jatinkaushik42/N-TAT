# gui/dashboard.py

import sys
import os

# Fix for relative imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))

from gui.modules.ransomware_gui import RansomwareGUI
from gui.modules.malware_gui import MalwareGUI
from gui.modules.ip_locator_gui import IPLocatorGUI
from gui.modules.charts_gui import ChartsGUI
from gui.modules.report_gui import ReportGUI
from gui.modules.tracer_gui import TracerGUI

# बाकी code नीचे जैसा था वैसा ही रखना
import tkinter as tk

class Dashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("N-TAT Dashboard")
        self.geometry("1000x700")
        self.configure(bg="black")
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Welcome to N-TAT Dashboard", font=("Helvetica", 22), fg="cyan", bg="black").pack(pady=20)

        tk.Button(self, text="Ransomware Generator", command=RansomwareGUI, width=40, height=2, bg="#1f1f1f", fg="white").pack(pady=10)
        tk.Button(self, text="Malware Detector", command=MalwareGUI, width=40, height=2, bg="#1f1f1f", fg="white").pack(pady=10)
        tk.Button(self, text="IP Locator", command=IPLocatorGUI, width=40, height=2, bg="#1f1f1f", fg="white").pack(pady=10)
        tk.Button(self, text="Charts & Graphs", command=ChartsGUI, width=40, height=2, bg="#1f1f1f", fg="white").pack(pady=10)
        tk.Button(self, text="Generate Report", command=ReportGUI, width=40, height=2, bg="#1f1f1f", fg="white").pack(pady=10)
        tk.Button(self, text="IP/MAC Tracer", command=TracerGUI, width=40, height=2, bg="#1f1f1f", fg="white").pack(pady=10)

if __name__ == "__main__":
    app = Dashboard()
    app.mainloop()

