# gui/modules/tracer_gui.py
# gui/modules/tracer_gui.py

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit
import requests


class TracerGUI(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("IP Tracer")
        self.setGeometry(100, 100, 600, 400)
        layout = QVBoxLayout()

        self.ip_input = QLineEdit()
        self.ip_input.setPlaceholderText("Enter IP Address")
        layout.addWidget(self.ip_input)

        self.trace_button = QPushButton("Trace IP")
        self.trace_button.clicked.connect(self.trace_ip)
        layout.addWidget(self.trace_button)

        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        layout.addWidget(self.result_box)

        self.setLayout(layout)

    def trace_ip(self):
        ip = self.ip_input.text()
        if not ip:
            self.result_box.setText("Please enter an IP address.")
            return
        try:
            response = requests.get(f"http://ip-api.com/json/{ip}")
            data = response.json()
            result = f"""
            IP: {data.get('query')}
            Country: {data.get('country')}
            Region: {data.get('regionName')}
            City: {data.get('city')}
            ISP: {data.get('isp')}
            Org: {data.get('org')}
            Lat/Lon: {data.get('lat')}, {data.get('lon')}
            """
            self.result_box.setText(result)
        except Exception as e:
            self.result_box.setText(f"Error tracing IP: {e}")


