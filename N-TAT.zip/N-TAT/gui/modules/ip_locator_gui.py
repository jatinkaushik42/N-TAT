# gui/modules/ip_locator_gui.py


from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QTextEdit
import requests

class IPLocatorGUI(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.input_ip = QLineEdit()
        self.input_ip.setPlaceholderText("Enter IP address")

        self.locate_btn = QPushButton("Locate IP")
        self.locate_btn.clicked.connect(self.locate_ip)

        self.output = QTextEdit()
        self.output.setReadOnly(True)

        layout.addWidget(QLabel("🌍 IP Locator"))
        layout.addWidget(self.input_ip)
        layout.addWidget(self.locate_btn)
        layout.addWidget(self.output)

        self.setLayout(layout)

    def locate_ip(self):
        ip = self.input_ip.text()
        try:
            res = requests.get(f"http://ip-api.com/json/{ip}").json()
            result = "\n".join(f"{k}: {v}" for k, v in res.items())
            self.output.setText(result)
        except Exception as e:
            self.output.setText(f"Error: {e}")

