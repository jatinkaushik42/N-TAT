# gui/modules/report_gui.py

# gui/modules/report_gui.py

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTextEdit, QPushButton, QFileDialog
import datetime


class ReportGUI(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Generate Report")
        self.setGeometry(100, 100, 600, 400)
        layout = QVBoxLayout()

        self.report_text = QTextEdit()
        self.report_text.setPlaceholderText("Scan details and logs will appear here.")
        layout.addWidget(self.report_text)

        self.save_button = QPushButton("Save Report")
        self.save_button.clicked.connect(self.save_report)
        layout.addWidget(self.save_button)

        self.setLayout(layout)
        self.generate_dummy_report()

    def generate_dummy_report(self):
        now = datetime.datetime.now()
        report = f"""
        ==== Network Threat Attribution Tool Report ====
        Timestamp: {now}
        - IP-MAC Mapping: Completed
        - Suspicious Activity: 3 Hosts Flagged
        - Malware Scans: 1 threat detected
        - Location Tracking: Successful
        - Ransomware Generator: Triggered with passkey
        """
        self.report_text.setText(report)

    def save_report(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Report", "report.txt", "Text Files (*.txt)")
        if file_path:
            with open(file_path, 'w') as file:
                file.write(self.report_text.toPlainText())

