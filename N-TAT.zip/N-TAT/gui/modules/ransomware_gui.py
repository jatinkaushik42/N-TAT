# ransomware GUI code...
# gui/modules/ransomware_gui.py
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QFileDialog, QMessageBox

class RansomwareGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.label = QLabel("🔐 Ransomware Generator", self)
        self.label.setStyleSheet("font-size: 20px; font-weight: bold; color: red;")

        self.gen_btn = QPushButton("Generate Ransomware", self)
        self.gen_btn.clicked.connect(self.generate_ransomware)

        layout.addWidget(self.label)
        layout.addWidget(self.gen_btn)
        self.setLayout(layout)

    def generate_ransomware(self):
        # Placeholder logic
        QMessageBox.information(self, "Ransomware", "Ransomware generated successfully with auto-key!")


 
