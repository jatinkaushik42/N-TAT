# gui/modules/charts_gui.py

# gui/modules/charts_gui.py

from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class ChartsGUI(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Live Charts")
        self.setGeometry(100, 100, 600, 400)
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        self.layout.addWidget(self.canvas)

        self.plot_chart()

    def plot_chart(self):
        ax = self.figure.add_subplot(111)
        ax.clear()
        ax.set_title("Suspicious Packets Detected Over Time")
        ax.set_xlabel("Time")
        ax.set_ylabel("Packet Count")
        ax.plot([1, 2, 3, 4, 5], [5, 15, 7, 20, 25], color='blue', marker='o')
        self.canvas.draw()

