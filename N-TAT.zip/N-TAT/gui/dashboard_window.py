from PyQt5.QtWidgets import QMainWindow, QWidget, QLabel, QVBoxLayout, QPushButton, QStackedWidget, QHBoxLayout
from PyQt5.QtCore import Qt

class DashboardWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("N-TAT Dashboard")
        self.setGeometry(100, 100, 1200, 700)
        self.setStyleSheet("background-color: #0D1117; color: white;")

        main_widget = QWidget()
        self.setCentralWidget(main_widget)

        self.sidebar = self.create_sidebar()
        self.stack = QStackedWidget()
        self.stack.addWidget(self.create_placeholder("IP to MAC Mapping"))
        self.stack.addWidget(self.create_placeholder("Malware Detection"))
        self.stack.addWidget(self.create_placeholder("Suspicious Behavior"))

        layout = QHBoxLayout()
        layout.addWidget(self.sidebar)
        layout.addWidget(self.stack, 1)

        main_widget.setLayout(layout)

    def create_sidebar(self):
        sidebar = QWidget()
        sidebar.setFixedWidth(200)
        layout = QVBoxLayout()

        title = QLabel("N-TAT")
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: cyan;")
        title.setAlignment(Qt.AlignCenter)

        buttons = {
            "IP to MAC": 0,
            "Malware Detection": 1,
            "Suspicious Behavior": 2,
        }

        layout.addWidget(title)

        for text, index in buttons.items():
            btn = QPushButton(text)
            btn.setStyleSheet("background-color: #161B22; color: white; padding: 10px; border: 1px solid white;")
            btn.clicked.connect(lambda checked, i=index: self.stack.setCurrentIndex(i))
            layout.addWidget(btn)

        layout.addStretch()
        sidebar.setLayout(layout)
        return sidebar

    def create_placeholder(self, text):
        widget = QWidget()
        layout = QVBoxLayout()
        label = QLabel(text)
        label.setStyleSheet("font-size: 20px;")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)
        widget.setLayout(layout)
        return widget

