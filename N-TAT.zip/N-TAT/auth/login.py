import sqlite3

def create_user_table():
    conn = sqlite3.connect('auth/users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT NOT NULL)''')
    conn.commit()
    conn.close()

def add_default_user():
    conn = sqlite3.connect('auth/users.db')
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)", ('jatin', 'jatin@123'))
    conn.commit()
    conn.close()

def validate_user(username, password):
    conn = sqlite3.connect('auth/users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    result = c.fetchone()
    conn.close()
    return result is not None

if __name__ == '__main__':
    create_user_table()
    add_default_user()
    print("Auth ready.")
