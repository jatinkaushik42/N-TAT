N-TAT setup instructions.
