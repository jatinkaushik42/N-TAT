import datetime

def generate_report(data, filename="report.txt"):
    with open(filename, 'w') as file:
        file.write("N-TAT Scan Report\n")
        file.write(f"Generated: {datetime.datetime.now()}\n\n")
        for section, items in data.items():
            file.write(f"--- {section} ---\n")
            for item in items:
                file.write(f"{item}\n")
            file.write("\n")
    return filename

if __name__ == "__main__":
    sample = {"IP-MAC": ["192.168.1.1 -> aa:bb:cc:dd:ee:ff"]}
    print("Report saved as:", generate_report(sample))
