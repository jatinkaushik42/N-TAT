import subprocess

def get_ip_mac():
    result = subprocess.check_output("arp -a", shell=True).decode()
    return result

if __name__ == "__main__":
    print(get_ip_mac())
