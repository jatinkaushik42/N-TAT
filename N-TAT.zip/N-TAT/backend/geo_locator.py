import requests

def locate_ip(ip_address):
    url = f"http://ip-api.com/json/{ip_address}"
    response = requests.get(url).json()
    return response

if __name__ == "__main__":
    ip = input("Enter IP address: ")
    print(locate_ip(ip))
