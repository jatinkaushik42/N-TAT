import os
from cryptography.fernet import Fernet

def generate_key():
    return Fernet.generate_key()

def encrypt_files(folder_path, key):
    f = Fernet(key)
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            full_path = os.path.join(root, file)
            with open(full_path, 'rb') as original_file:
                data = original_file.read()
            encrypted = f.encrypt(data)
            with open(full_path, 'wb') as encrypted_file:
                encrypted_file.write(encrypted)

if __name__ == "__main__":
    path = input("Enter folder path to encrypt: ")
    key = generate_key()
    print("Encryption Key:", key.decode())
    encrypt_files(path, key)
